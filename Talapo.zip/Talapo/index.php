<?php
header("Location: facturas.php");
?>